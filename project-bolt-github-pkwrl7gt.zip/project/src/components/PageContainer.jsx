export default function PageContainer({ children }) {
  return <div className="page">{children}</div>;
}
